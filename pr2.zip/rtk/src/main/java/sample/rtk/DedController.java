package sample.rtk;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

public class DedController {
    @FXML
    public ImageView Ded;
    @FXML
    public Button CerepPlus;
    public Button CerepMinus;
    public Text CerepCislo;
    public Button BabockaPlus;
    public Button BabockaMinus;
    public Text BabockaCislo;
    public Button BotyPlus;
    public Button BotyMinus;
    public Text BotyCislo;
    public Button SlonPlus;
    public Button SlonMinus;
    public Text SlonCislo;
    public Button DedPlus;
    public Button DedMinus;
    public Text DedCislo;
    public Button CasyPlus;
    public Button CasyMinus;
    public Text CasyCislo;
    public Button AquaPlus;
    public Button AquaMinus;
    public Text AquaCislo;
    public Button CajPlus;
    public Button CajMinus;
    public Text CajCislo;

    private CounterController cerepController;
    private CounterController babockaController;
    private CounterController botyController;
    private CounterController slonController;
    private CounterController dedController;
    private CounterController casyController;
    private CounterController aquaController;
    private CounterController cajController;

    @FXML
    void initialize() {
        cerepController = new CounterController(CerepCislo);
        babockaController = new CounterController(BabockaCislo);
        botyController = new CounterController(BotyCislo);
        slonController = new CounterController(SlonCislo);
        dedController = new CounterController(DedCislo);
        casyController = new CounterController(CasyCislo);
        aquaController = new CounterController(AquaCislo);
        cajController = new CounterController(CajCislo);

        CerepPlus.setOnAction(event -> cerepController.incrementCounter());
        CerepMinus.setOnAction(event -> cerepController.decrementCounter());

        BabockaPlus.setOnAction(event -> babockaController.incrementCounter());
        BabockaMinus.setOnAction(event -> babockaController.decrementCounter());

        BotyPlus.setOnAction(event -> botyController.incrementCounter());
        BotyMinus.setOnAction(event -> botyController.decrementCounter());

        SlonPlus.setOnAction(event -> slonController.incrementCounter());
        SlonMinus.setOnAction(event -> slonController.decrementCounter());

        DedPlus.setOnAction(event -> dedController.incrementCounter());
        DedMinus.setOnAction(event -> dedController.decrementCounter());

        CasyPlus.setOnAction(event -> casyController.incrementCounter());
        CasyMinus.setOnAction(event -> casyController.decrementCounter());

        AquaPlus.setOnAction(event -> aquaController.incrementCounter());
        AquaMinus.setOnAction(event -> aquaController.decrementCounter());

        CajPlus.setOnAction(event -> cajController.incrementCounter());
        CajMinus.setOnAction(event -> cajController.decrementCounter());
    }

    static class CounterController {
        private Text counterText;

        public CounterController(Text counterText) {
            this.counterText = counterText;
        }

        public void incrementCounter() {
            int currentNumber = Integer.parseInt(counterText.getText());
            counterText.setText(String.valueOf(currentNumber + 1));
        }

        public void decrementCounter() {
            int currentNumber = Integer.parseInt(counterText.getText());
            if (currentNumber > 0) {
                counterText.setText(String.valueOf(currentNumber - 1));
            }
        }
    }
}
