package sample.rtk;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class SignUpController {


    @FXML
    public ComboBox gender;
    public Button ButtonBack;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField login_field;

    @FXML
    private PasswordField password_field;

    @FXML
    private Button signUpButton;

    @FXML
    private ComboBox signUpCountry;

    @FXML
    private TextField signUpName;

    @FXML
    private TextField signUpPol;

    @FXML
    private TextField signUpSurname;

    @FXML
    void initialize() {
        gender.getItems().addAll("Man", "Woman");
        signUpCountry.getItems().addAll("Africa", "Antarctica", "Asia", "Australia", "Europe", "North America", "South America");

        ButtonBack.setOnAction(event -> {
            ButtonBack.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("sample.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setTitle("Voice art");
            stage.getIcons().add(new Image(Objects.requireNonNull(Main.class.getResourceAsStream("img.jpg"))));
            stage.setScene(new Scene(root));
            stage.showAndWait();
        });

        signUpButton.setOnAction(event -> {
            signUpButton.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("app.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setTitle("Voice art");
            stage.getIcons().add(new Image(Objects.requireNonNull(Main.class.getResourceAsStream("img.jpg"))));
            stage.setScene(new Scene(root));
            stage.showAndWait();
        });
    }

}